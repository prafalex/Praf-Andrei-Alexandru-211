#include <iostream>
#include <string.h>
#include <vector>

using namespace std;

class decoratiune
{
private:
    bool reciclabil;
    char *nume;
    float pret;
public:
    decoratiune(){
        reciclabil=0;
        nume=new char[strlen("Necunoscut")+1];
        strcpy(nume,"Necunoscut");
        pret=0.0f;
    }
    decoratiune(bool reciclabil,char*nume,float pret)
    {
        this->reciclabil=reciclabil;
        this->nume=new char[strlen(nume)+1];
        strcpy(this->nume,nume);
        this->pret=pret;
    }
    bool getRecic(){
        return this->reciclabil;
    }
    char *getNume()
    {
        return this->nume;

    }
    float getpret()
    {
        return this->pret;
    }

    friend ostream&operator<<(ostream &out,const decoratiune deco)
    {
        out<<deco.nume<<" are pretul: "<<deco.pret<<" lei.Este reciclabila(1/0)"<<deco.reciclabil;
        return out;
    }
    friend istream&operator>>(istream &in,decoratiune &deco)
    {
        char aux[100];
        cout<<"Introduceti numele decoratiunii: \n";
        in>>aux;
        if(deco.nume!=NULL)
            delete[]deco.nume;
        deco.nume=new char[strlen(aux)+1];
        strcpy(deco.nume,aux);
        cout<<"Pretul produsului:\n";
        in>>deco.pret;
        cout<<"Este reciclabil(1/0):\n";
        in>>deco.reciclabil;
        return in;
    }

};
class listaproduse:public decoratiune
{
public:
    vector<decoratiune> listadec;
    void afisdeco(){
        cout<<"Pe lista avem:\n";
        for(int i=0;i<listadec.size();i++)
        {
            cout<<listadec[i].getNume()<< " cu pretul: "<< listadec[i].getpret()<<
            " si este reciclabil:"<<listadec[i].getRecic();
        }
    }
    float pret()
    {
        float total=0;
        for(int i=0;i<listadec.size();i++)
            total=total+listadec[i].getpret();
        return total;
    }


};
int main()
{
    listaproduse b;
    decoratiune a;
    cin>>a;
    b.listadec.push_back(a);
    cout<<b.pret();


    return 0;
}
